

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class ProfileServlet extends HttpServlet { 

    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/csm3023";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASSWORD = "admin";

    // doGet() method to handle GET requests (showing the form)
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Forward to doPost to handle form submission
        doPost(request, response);
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve form data
        String username = request.getParameter("username");
        String icno = request.getParameter("icno");
        String firstname = request.getParameter("firstname");

        Connection conn = null;
        PreparedStatement pstmt = null;
        PrintWriter out = response.getWriter();

        try {
            // Register JDBC driver (if not already done)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Open a connection
            conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);

            // SQL query to insert data into userprofile table
            String sql = "INSERT INTO userprofile (username, icno, firstname) VALUES (?, ?, ?)";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username);
            pstmt.setString(2, icno);
            pstmt.setString(3, firstname);

            // Execute the insert statement
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                out.println("<html><body>");
                out.println("<h2>Profile Registered Successfully</h2>");
                out.println("<p>Username: " + username + "</p>");
                out.println("<p>First Name: " + firstname + "</p>");
                out.println("<a href='profileForm.jsp'>Go back to Registration Form</a>");
                out.println("</body></html>");
            } else {
                out.println("<html><body>");
                out.println("<h2>Failed to Register Profile</h2>");
                out.println("<a href='profileForm.jsp'>Go back to Registration Form</a>");
                out.println("</body></html>");
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            out.println("Exception occurred: " + e.getMessage());
        } finally {
            // Clean up resources
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

}
