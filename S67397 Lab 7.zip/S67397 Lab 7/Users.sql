create table users(
userid varchar(15) not null,
firstname varchar(35),
lastname varchar(15),
constraint users_userid_pk primary key (userid)
)