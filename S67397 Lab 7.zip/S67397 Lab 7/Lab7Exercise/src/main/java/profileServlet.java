import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/profileServlet")
public class profileServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { 
        response.sendError(HttpServletResponse.SC_METHOD_NOT_ALLOWED, "GET method is not supported.");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String userName = request.getParameter("username");
        String ICno = request.getParameter("icno");
        String firstName = request.getParameter("firstname");

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Database connection details
        String jdbcURL = "jdbc:mysql://localhost:3306/csm3023";
        String dbUser = "root";
        String dbPassword = "admin";

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            // Load the database driver
            Class.forName("com.mysql.jdbc.Driver");

            // Establish connection to the database
            connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

            // Insert data into the userprofile table
            String sql = "INSERT INTO userprofile (username, icno, firstname) VALUES (?, ?, ?)";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, userName);
            preparedStatement.setString(2, ICno);
            preparedStatement.setString(3, firstName);

            int result = preparedStatement.executeUpdate();

            if (result > 0) {
                out.println("<h1>Profile Registration Successful!</h1>");
                out.println("<p>Username: " + userName + "</p>");
                out.println("<p>IC Number: " + ICno + "</p>");
                out.println("<p>First Name: " + firstName + "</p>");
            } else {
                out.println("<h1>Profile Registration Failed!</h1>");
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            out.println("<h1>Error: " + e.getMessage() + "</h1>");
        } finally {
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public String getServletInfo() {
        return "Servlet for user profile registration.";
    }
}
